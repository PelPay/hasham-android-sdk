package com.chamsswitch.hasham.mobile.model

/** Returned after successful device enrollment. */
data class EnrollmentResult(
    /** The device ID — store this to include in requests to your backend (X-Device-ID header). */
    val deviceId: String,
)

package com.chamsswitch.hasham.mobile.ui

import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import kotlin.coroutines.Continuation
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCoroutine

/**
 * SDK-owned PIN entry bottom sheet. The host app never receives raw digit input.
 * Built programmatically — no XML layouts required, avoiding resource name conflicts.
 * Colors and fonts are resolved from the host app's Material theme unless explicitly
 * overridden via [PinTheme].
 */
internal class PinEntryFragment : BottomSheetDialogFragment() {

    companion object {
        private const val MIN_LENGTH = 4

        fun newInstance(theme: PinTheme): PinEntryFragment =
            PinEntryFragment().also { it.theme = theme }
    }

    internal var theme: PinTheme = PinTheme()

    private lateinit var colors: ThemeColors
    private var resolvedTypeface: android.graphics.Typeface? = null

    private val digits = mutableListOf<Char>()
    private var continuation: Continuation<CharArray>? = null

    private val dotViews = mutableListOf<View>()

    // MARK: - Lifecycle

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        colors = resolveThemeColors(requireContext(), theme.colors)
        resolvedTypeface = resolveTypeface(requireContext(), theme.typography)
        return buildRootView()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        continuation?.let { cont ->
            continuation = null
            zeroClear()
            cont.resumeWithException(IllegalStateException("CANCELLED"))
        }
    }

    // MARK: - Public API

    suspend fun awaitPin(): CharArray = suspendCoroutine { continuation = it }

    // MARK: - Root view (programmatic layout)

    private fun buildRootView(): View {
        val root = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            gravity     = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(colors.background)
            setPadding(dp(24), dp(32), dp(24), dp(40))
        }

        // Close button row
        val closeTv = TextView(requireContext()).apply {
            text      = "×"
            textSize  = 22f
            setTextColor(colors.subtitleColor)
            typeface  = resolvedTypeface
            setOnClickListener { cancel() }
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        root.addView(LinearLayout(requireContext()).apply {
            orientation  = LinearLayout.HORIZONTAL
            gravity      = Gravity.END
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT,
            )
            addView(closeTv)
        })

        // Title
        root.addView(TextView(requireContext()).apply {
            text      = theme.strings.title
            textSize  = theme.typography.titleSizeSp
            setTextColor(colors.titleColor)
            gravity   = Gravity.CENTER
            typeface  = android.graphics.Typeface.create(resolvedTypeface, android.graphics.Typeface.BOLD)
            layoutParams = marginParams(bottom = dp(8))
        })

        // Subtitle
        root.addView(TextView(requireContext()).apply {
            text      = theme.strings.subtitle
            textSize  = theme.typography.subtitleSizeSp
            setTextColor(colors.subtitleColor)
            gravity   = Gravity.CENTER
            typeface  = resolvedTypeface
            layoutParams = marginParams(bottom = dp(28))
        })

        // Dot indicators
        root.addView(buildDotRow())

        // Keypad
        root.addView(buildKeypad())

        // Cancel button
        root.addView(buildCancelButton())

        return root
    }

    // MARK: - Dots

    private fun buildDotRow(): LinearLayout {
        dotViews.clear()
        val row = LinearLayout(requireContext()).apply {
            orientation  = LinearLayout.HORIZONTAL
            gravity      = Gravity.CENTER
            layoutParams = marginParams(bottom = dp(32))
        }
        repeat(theme.pinLength) {
            val dot = View(requireContext()).apply {
                val size = dp(14)
                layoutParams = LinearLayout.LayoutParams(size, size).also {
                    it.setMargins(dp(6), 0, dp(6), 0)
                }
                background = circleDrawable(colors.dotEmpty)
            }
            dotViews.add(dot)
            row.addView(dot)
        }
        return row
    }

    private fun refreshDots() {
        dotViews.forEachIndexed { i, dot ->
            val color = if (i < digits.size) colors.dotFilled else colors.dotEmpty
            dot.background = circleDrawable(color)
        }
    }

    // MARK: - Keypad

    private fun buildKeypad(): LinearLayout {
        val keypad = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            gravity     = Gravity.CENTER
        }
        val rows = listOf(
            listOf("1", "2", "3"),
            listOf("4", "5", "6"),
            listOf("7", "8", "9"),
            listOf("⌫", "0", "✓"),
        )
        for (row in rows) {
            val rowView = LinearLayout(requireContext()).apply {
                orientation  = LinearLayout.HORIZONTAL
                gravity      = Gravity.CENTER
                layoutParams = marginParams(bottom = dp(12))
            }
            for (label in row) rowView.addView(buildKey(label))
            keypad.addView(rowView)
        }
        return keypad
    }

    private fun buildKey(label: String): View {
        val size        = dp(72)
        val isConfirm   = label == "✓"
        val isBackspace = label == "⌫"

        return TextView(requireContext()).apply {
            text      = label
            textSize  = theme.typography.keySizeSp
            gravity   = Gravity.CENTER
            typeface  = resolvedTypeface
            setTextColor(if (isConfirm) colors.onPrimary else colors.keyText)

            layoutParams = LinearLayout.LayoutParams(size, size).also { lp ->
                lp.setMargins(dp(8), 0, dp(8), 0)
            }
            background = keyBackground(
                color        = if (isConfirm) colors.primary else colors.keyBackground,
                keyShape     = theme.shape.keyShape,
                cornerRadius = theme.shape.cornerRadius,
            )

            if (isConfirm) {
                alpha     = 0.4f
                isEnabled = false
                tag       = "confirm_key"
            }

            setOnClickListener {
                when {
                    isBackspace -> onBackspace()
                    isConfirm   -> onConfirm()
                    else        -> onDigit(label[0])
                }
            }
        }
    }

    private fun buildCancelButton(): View =
        TextView(requireContext()).apply {
            text      = "Cancel"
            textSize  = 15f
            gravity   = Gravity.CENTER
            typeface  = resolvedTypeface
            setTextColor(colors.subtitleColor)
            layoutParams = marginParams(top = dp(16), bottom = dp(8)).apply {
                height = dp(48)
            }
            setOnClickListener { cancel() }
        }

    // MARK: - Input handling

    private fun onDigit(c: Char) {
        if (digits.size >= theme.pinLength) return
        digits.add(c)
        refreshDots()
        refreshConfirm()
        if (digits.size == theme.pinLength) onConfirm()
    }

    private fun onBackspace() {
        if (digits.isEmpty()) return
        digits.removeLast()
        refreshDots()
        refreshConfirm()
    }

    private fun onConfirm() {
        if (digits.size < MIN_LENGTH) return
        val cont = continuation ?: return
        continuation = null
        val result = digits.toCharArray()
        zeroClear()
        cont.resume(result)
    }

    private fun cancel() {
        val cont = continuation ?: return
        continuation = null
        zeroClear()
        cont.resumeWithException(IllegalStateException("CANCELLED"))
        dismissAllowingStateLoss()
    }

    private fun refreshConfirm() {
        val enabled = digits.size >= MIN_LENGTH
        view?.findViewWithTag<TextView>("confirm_key")?.let { tv ->
            tv.isEnabled = enabled
            tv.animate().alpha(if (enabled) 1f else 0.4f).setDuration(150).start()
        }
    }

    // MARK: - Helpers

    private fun zeroClear() {
        digits.fill('0')
        digits.clear()
    }

    private fun dp(value: Int): Int =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            requireContext().resources.displayMetrics,
        ).toInt()

    private fun circleDrawable(color: Int): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
        }

    private fun keyBackground(
        color:        Int,
        keyShape:     PinTheme.KeyShape,
        cornerRadius: Float,
    ): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        when (keyShape) {
            PinTheme.KeyShape.CIRCLE  -> shape = GradientDrawable.OVAL
            PinTheme.KeyShape.ROUNDED -> {
                shape = GradientDrawable.RECTANGLE
                this.cornerRadius = TypedValue.applyDimension(
                    TypedValue.COMPLEX_UNIT_DIP, cornerRadius,
                    requireContext().resources.displayMetrics,
                )
            }
            PinTheme.KeyShape.SQUARE  -> {
                shape             = GradientDrawable.RECTANGLE
                this.cornerRadius = 0f
            }
        }
    }

    private fun marginParams(
        top: Int = 0, bottom: Int = 0, start: Int = 0, end: Int = 0,
    ): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT,
        ).also { it.setMargins(start, top, end, bottom) }
}

package com.chamsswitch.hasham.mobile.ui

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import kotlin.coroutines.Continuation
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCoroutine

/**
 * Collects the hidden digits of a physical card's PAN from the cardholder.
 *
 * Receives a masked PAN (e.g. "4111 **** **** 1234"), displays it, and shows a numeric
 * keypad for the hidden positions. Returns the reconstructed full PAN via [awaitPan].
 * Colors and fonts inherit from the host app's Material theme unless overridden via [theme].
 */
internal class PanEntryFragment : BottomSheetDialogFragment() {

    companion object {
        fun newInstance(maskedPan: String, theme: PinTheme): PanEntryFragment =
            PanEntryFragment().also {
                it.maskedPan = maskedPan
                it.theme     = theme
            }
    }

    internal var maskedPan: String = ""
    internal var theme: PinTheme   = PinTheme()

    private lateinit var colors: ThemeColors
    private var resolvedTypeface: android.graphics.Typeface? = null

    // Known chars at each position; null marks a hidden digit to fill.
    private lateinit var panChars: Array<Char?>
    private val hiddenIndices  = mutableListOf<Int>()  // positions in panChars that are null
    private val enteredDigits  = mutableListOf<Char>() // user-entered digits, left to right

    private val inputBoxes = mutableListOf<TextView>()
    private var confirmKey: TextView? = null

    private var continuation: Continuation<String>? = null

    // MARK: - Lifecycle

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        colors = resolveThemeColors(requireContext(), theme.colors)
        resolvedTypeface = resolveTypeface(requireContext(), theme.typography)
        parseMaskedPan()
        return buildRootView()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        continuation?.let { cont ->
            continuation = null
            zeroClear()
            cont.resumeWithException(IllegalStateException("CANCELLED"))
        }
    }

    // MARK: - Public API

    suspend fun awaitPan(): String = suspendCoroutine { continuation = it }

    // MARK: - Setup

    private fun parseMaskedPan() {
        val stripped = maskedPan.replace(" ", "")
        panChars = Array(stripped.length) { i ->
            if (stripped[i] == '*') null else stripped[i]
        }
        hiddenIndices.clear()
        panChars.forEachIndexed { i, c -> if (c == null) hiddenIndices.add(i) }
    }

    // MARK: - Root view

    private fun buildRootView(): View {
        val root = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            gravity     = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(colors.background)
            setPadding(dp(24), dp(32), dp(24), dp(40))
        }

        // Close button row
        root.addView(LinearLayout(requireContext()).apply {
            orientation  = LinearLayout.HORIZONTAL
            gravity      = Gravity.END
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT,
            )
            addView(TextView(requireContext()).apply {
                text     = "×"
                textSize = 22f
                setTextColor(colors.subtitleColor)
                typeface = resolvedTypeface
                setPadding(dp(8), dp(8), dp(8), dp(8))
                setOnClickListener { cancel() }
            })
        })

        // Title
        root.addView(TextView(requireContext()).apply {
            text      = "Verify your card"
            textSize  = theme.typography.titleSizeSp
            setTextColor(colors.titleColor)
            gravity   = Gravity.CENTER
            typeface  = android.graphics.Typeface.create(resolvedTypeface, android.graphics.Typeface.BOLD)
            layoutParams = marginParams(bottom = dp(8))
        })

        // Masked PAN display — shows '•' for hidden digits
        root.addView(TextView(requireContext()).apply {
            text      = maskedPan.replace('*', '•')
            textSize  = 18f
            setTextColor(colors.subtitleColor)
            gravity   = Gravity.CENTER
            typeface  = resolvedTypeface
            layoutParams = marginParams(bottom = dp(6))
        })

        // Instruction
        root.addView(TextView(requireContext()).apply {
            text      = "Enter the ${hiddenIndices.size} hidden digits"
            textSize  = theme.typography.subtitleSizeSp
            setTextColor(colors.subtitleColor)
            gravity   = Gravity.CENTER
            typeface  = resolvedTypeface
            layoutParams = marginParams(bottom = dp(24))
        })

        // Input boxes — one per hidden digit
        root.addView(buildInputBoxRow())

        // Keypad
        root.addView(buildKeypad())

        return root
    }

    // MARK: - Input boxes

    private fun buildInputBoxRow(): LinearLayout {
        inputBoxes.clear()
        val row = LinearLayout(requireContext()).apply {
            orientation  = LinearLayout.HORIZONTAL
            gravity      = Gravity.CENTER
            layoutParams = marginParams(bottom = dp(28))
        }
        repeat(hiddenIndices.size) {
            val box = TextView(requireContext()).apply {
                text      = "_"
                textSize  = 20f
                gravity   = Gravity.CENTER
                setTextColor(colors.subtitleColor)
                typeface  = resolvedTypeface
                layoutParams = LinearLayout.LayoutParams(dp(32), dp(40)).also { lp ->
                    lp.setMargins(dp(4), 0, dp(4), 0)
                }
                background = inputBoxDrawable(colors.dotEmpty)
            }
            inputBoxes.add(box)
            row.addView(box)
        }
        return row
    }

    private fun refreshInputBoxes() {
        inputBoxes.forEachIndexed { i, box ->
            val entered = enteredDigits.getOrNull(i)
            if (entered != null) {
                box.text = entered.toString()
                box.setTextColor(colors.keyText)
            } else {
                box.text = "_"
                box.setTextColor(colors.subtitleColor)
            }
        }
        refreshConfirmKey()
    }

    // MARK: - Keypad

    private fun buildKeypad(): LinearLayout {
        val keypad = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            gravity     = Gravity.CENTER
        }
        val rows = listOf(
            listOf("1", "2", "3"),
            listOf("4", "5", "6"),
            listOf("7", "8", "9"),
            listOf("⌫", "0", "✓"),
        )
        for (row in rows) {
            val rowView = LinearLayout(requireContext()).apply {
                orientation  = LinearLayout.HORIZONTAL
                gravity      = Gravity.CENTER
                layoutParams = marginParams(bottom = dp(12))
            }
            for (label in row) rowView.addView(buildKey(label))
            keypad.addView(rowView)
        }
        return keypad
    }

    private fun buildKey(label: String): View {
        val size        = dp(72)
        val isConfirm   = label == "✓"
        val isBackspace = label == "⌫"

        return TextView(requireContext()).apply {
            text      = label
            textSize  = theme.typography.keySizeSp
            gravity   = Gravity.CENTER
            typeface  = resolvedTypeface
            setTextColor(if (isConfirm) colors.onPrimary else colors.keyText)

            layoutParams = LinearLayout.LayoutParams(size, size).also { lp ->
                lp.setMargins(dp(8), 0, dp(8), 0)
            }
            background = keyBackground(
                color        = if (isConfirm) colors.primary else colors.keyBackground,
                keyShape     = theme.shape.keyShape,
                cornerRadius = theme.shape.cornerRadius,
            )

            if (isConfirm) {
                alpha     = 0.4f
                isEnabled = false
                confirmKey = this
            }

            setOnClickListener {
                when {
                    isBackspace -> onBackspace()
                    isConfirm   -> onConfirm()
                    else        -> onDigit(label[0])
                }
            }
        }
    }

    // MARK: - Input handling

    private fun onDigit(c: Char) {
        if (enteredDigits.size >= hiddenIndices.size) return
        enteredDigits.add(c)
        refreshInputBoxes()
        if (enteredDigits.size == hiddenIndices.size) onConfirm()
    }

    private fun onBackspace() {
        if (enteredDigits.isEmpty()) return
        enteredDigits.removeLast()
        refreshInputBoxes()
    }

    private fun onConfirm() {
        if (enteredDigits.size < hiddenIndices.size) return
        val cont = continuation ?: return
        continuation = null
        val pan = reconstructPan()
        zeroClear()
        cont.resume(pan)
    }

    private fun cancel() {
        val cont = continuation ?: return
        continuation = null
        zeroClear()
        cont.resumeWithException(IllegalStateException("CANCELLED"))
        dismissAllowingStateLoss()
    }

    private fun refreshConfirmKey() {
        val allFilled = enteredDigits.size >= hiddenIndices.size
        confirmKey?.let { key ->
            key.isEnabled = allFilled
            key.animate().alpha(if (allFilled) 1f else 0.4f).setDuration(150).start()
        }
    }

    // MARK: - PAN reconstruction

    private fun reconstructPan(): String {
        val result = panChars.clone()
        hiddenIndices.forEachIndexed { slot, panIdx ->
            result[panIdx] = enteredDigits[slot]
        }
        return result.joinToString("") { it!!.toString() }
    }

    // MARK: - Helpers

    private fun zeroClear() {
        enteredDigits.fill('0')
        enteredDigits.clear()
    }

    private fun dp(value: Int): Int =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            requireContext().resources.displayMetrics,
        ).toInt()

    private fun inputBoxDrawable(borderColor: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(Color.TRANSPARENT)
            setStroke(dp(1), borderColor)
            shape = GradientDrawable.RECTANGLE
            cornerRadius = TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, 4f,
                requireContext().resources.displayMetrics,
            )
        }

    private fun keyBackground(
        color:        Int,
        keyShape:     PinTheme.KeyShape,
        cornerRadius: Float,
    ): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        when (keyShape) {
            PinTheme.KeyShape.CIRCLE  -> shape = GradientDrawable.OVAL
            PinTheme.KeyShape.ROUNDED -> {
                shape = GradientDrawable.RECTANGLE
                this.cornerRadius = TypedValue.applyDimension(
                    TypedValue.COMPLEX_UNIT_DIP, cornerRadius,
                    requireContext().resources.displayMetrics,
                )
            }
            PinTheme.KeyShape.SQUARE  -> {
                shape             = GradientDrawable.RECTANGLE
                this.cornerRadius = 0f
            }
        }
    }

    private fun marginParams(
        top: Int = 0, bottom: Int = 0, start: Int = 0, end: Int = 0,
    ): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT,
        ).also { it.setMargins(start, top, end, bottom) }
}

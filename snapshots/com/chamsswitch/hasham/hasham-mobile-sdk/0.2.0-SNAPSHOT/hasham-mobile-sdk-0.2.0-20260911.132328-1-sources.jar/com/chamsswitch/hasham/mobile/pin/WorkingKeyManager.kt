package com.chamsswitch.hasham.mobile.pin

import android.content.Context
import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Stores the SSM-issued working key using envelope encryption.
 *
 * A hardware-backed AES-256-GCM key in Android Keystore (the "envelope key") wraps the
 * working key bytes. The envelope key is non-extractable — even code running in the same
 * process cannot obtain its raw bytes. The working key ciphertext is stored in plain
 * SharedPreferences; without the envelope key it is useless.
 *
 * [withKey] decrypts the working key into a temporary byte array, calls the supplied
 * block, then zeros the array — limiting the plaintext window to the duration of the call.
 */
internal class WorkingKeyManager(private val context: Context) {

    private val keyStore = KeyStore.getInstance("AndroidKeyStore").also { it.load(null) }
    private val prefs: SharedPreferences by lazy {
        context.getSharedPreferences("hasham_wk_store", Context.MODE_PRIVATE)
    }

    /** Wrap [workingKeyBytes] under the device envelope key and persist. Zeros [workingKeyBytes] on return. */
    fun store(deviceId: String, workingKeyBytes: ByteArray) {
        val envelopeKey = getOrCreateEnvelopeKey(deviceId)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, envelopeKey)
        val ciphertext = cipher.doFinal(workingKeyBytes)
        val iv = cipher.iv
        workingKeyBytes.fill(0)

        prefs.edit()
            .putString(prefKeyIv(deviceId), Base64.encodeToString(iv, Base64.NO_WRAP))
            .putString(prefKeyCiphertext(deviceId), Base64.encodeToString(ciphertext, Base64.NO_WRAP))
            .apply()
    }

    /**
     * Decrypt the working key, invoke [block] with the plaintext bytes, then zero them.
     * The raw working key bytes never escape this function.
     */
    fun <T> withKey(deviceId: String, block: (ByteArray) -> T): T {
        val envelopeKey = keyStore.getKey(envelopeAlias(deviceId), null) as? SecretKey
            ?: throw HashamEnrollmentException("Device not enrolled")
        val iv = Base64.decode(
            prefs.getString(prefKeyIv(deviceId), null) ?: throw HashamEnrollmentException("Device not enrolled"),
            Base64.NO_WRAP,
        )
        val ciphertext = Base64.decode(
            prefs.getString(prefKeyCiphertext(deviceId), null) ?: throw HashamEnrollmentException("Device not enrolled"),
            Base64.NO_WRAP,
        )
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, envelopeKey, GCMParameterSpec(GCM_TAG_BITS, iv))
        val plaintext = cipher.doFinal(ciphertext)
        return try {
            block(plaintext)
        } finally {
            plaintext.fill(0)
        }
    }

    fun isEnrolled(deviceId: String): Boolean =
        prefs.contains(prefKeyCiphertext(deviceId)) && keyStore.containsAlias(envelopeAlias(deviceId))

    fun clear(deviceId: String) {
        keyStore.deleteEntry(envelopeAlias(deviceId))
        prefs.edit()
            .remove(prefKeyIv(deviceId))
            .remove(prefKeyCiphertext(deviceId))
            .apply()
    }

    private fun getOrCreateEnvelopeKey(deviceId: String): SecretKey {
        val alias = envelopeAlias(deviceId)
        if (keyStore.containsAlias(alias)) {
            return keyStore.getKey(alias, null) as SecretKey
        }
        val spec = KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setKeySize(256)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            // Key cannot be exported — getEncoded() returns null on hardware-backed keys
            .build()
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
            .also { it.init(spec) }
            .generateKey()
    }

    private fun envelopeAlias(deviceId: String) = "hasham-envelope-$deviceId"
    private fun prefKeyIv(deviceId: String) = "wk_iv_$deviceId"
    private fun prefKeyCiphertext(deviceId: String) = "wk_ct_$deviceId"

    companion object {
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val GCM_TAG_BITS = 128
    }
}

class HashamEnrollmentException(message: String, cause: Throwable? = null) : Exception(message, cause)

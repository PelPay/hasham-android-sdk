package com.chamsswitch.hasham.mobile

data class HashamMobileConfig(
    /** Discovery document URL, e.g. "https://api.chamsswitch.com/auth/.well-known/mobile-sdk" */
    val discoveryUrl: String,
    /** HTTP timeout in milliseconds for all IAM calls. */
    val timeoutMs: Long = 30_000L,
)

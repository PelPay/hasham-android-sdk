package com.chamsswitch.hasham.mobile.enrollment

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import com.chamsswitch.hasham.mobile.pin.HashamEnrollmentException
import java.security.KeyFactory
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher
import javax.crypto.spec.OAEPParameterSpec
import javax.crypto.spec.PSource
import java.security.spec.MGF1ParameterSpec

/**
 * Persists the tenant RSA public key (enc_public_key) returned by IAM during attestation.
 * Used to wrap the clear PAN for PIN-change operations — the Card API unwraps it with
 * the matching private key stored in Vault.
 */
internal class EncPublicKeyManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("hasham_enc_pub_store", Context.MODE_PRIVATE)

    fun store(deviceId: String, pemPublicKey: String) {
        prefs.edit().putString(prefKey(deviceId), pemPublicKey).apply()
    }

    fun isAvailable(deviceId: String): Boolean = prefs.contains(prefKey(deviceId))

    /**
     * Encrypts [pan] with the stored RSA public key using RSA-OAEP-SHA256.
     * Returns base64-encoded ciphertext.
     */
    fun wrapPan(deviceId: String, pan: String): String {
        val pem = prefs.getString(prefKey(deviceId), null)
            ?: throw HashamEnrollmentException(
                "No enc_public_key stored for device $deviceId — tenant must configure an enc key"
            )
        val publicKey = parsePem(pem)
        val oaepParams = OAEPParameterSpec(
            "SHA-256", "MGF1", MGF1ParameterSpec.SHA256, PSource.PSpecified.DEFAULT,
        )
        val cipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding")
        cipher.init(Cipher.ENCRYPT_MODE, publicKey, oaepParams)
        val ciphertext = cipher.doFinal(pan.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(ciphertext, Base64.NO_WRAP)
    }

    private fun parsePem(pem: String): java.security.PublicKey {
        val stripped = pem
            .replace("-----BEGIN PUBLIC KEY-----", "")
            .replace("-----END PUBLIC KEY-----", "")
            .replace("\\s".toRegex(), "")
        val derBytes = Base64.decode(stripped, Base64.DEFAULT)
        return KeyFactory.getInstance("RSA").generatePublic(X509EncodedKeySpec(derBytes))
    }

    private fun prefKey(deviceId: String) = "enc_pub_$deviceId"
}

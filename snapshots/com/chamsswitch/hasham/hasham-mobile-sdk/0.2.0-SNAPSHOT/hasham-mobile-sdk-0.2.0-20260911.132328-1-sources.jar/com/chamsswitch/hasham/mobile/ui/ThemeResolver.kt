package com.chamsswitch.hasham.mobile.ui

import android.content.Context
import android.util.TypedValue
import androidx.core.content.res.ResourcesCompat

internal data class ThemeColors(
    val primary:       Int,
    val background:    Int,
    val keyBackground: Int,
    val keyText:       Int,
    val dotFilled:     Int,
    val dotEmpty:      Int,
    val titleColor:    Int,
    val subtitleColor: Int,
    val onPrimary:     Int,
)

internal fun resolveThemeColors(context: Context, overrides: PinTheme.Colors): ThemeColors {
    fun resolve(attr: Int): Int {
        val tv = TypedValue()
        context.theme.resolveAttribute(attr, tv, true)
        return tv.data
    }
    return ThemeColors(
        primary       = overrides.primary       ?: resolve(com.google.android.material.R.attr.colorPrimary),
        background    = overrides.background    ?: resolve(com.google.android.material.R.attr.colorSurface),
        keyBackground = overrides.keyBackground ?: resolve(com.google.android.material.R.attr.colorSurfaceVariant),
        keyText       = overrides.keyText       ?: resolve(com.google.android.material.R.attr.colorOnSurface),
        dotFilled     = overrides.dotFilled     ?: resolve(com.google.android.material.R.attr.colorPrimary),
        dotEmpty      = overrides.dotEmpty      ?: resolve(com.google.android.material.R.attr.colorOutlineVariant),
        titleColor    = overrides.titleColor    ?: resolve(com.google.android.material.R.attr.colorOnSurface),
        subtitleColor = overrides.subtitleColor ?: resolve(com.google.android.material.R.attr.colorOnSurfaceVariant),
        onPrimary     = resolve(com.google.android.material.R.attr.colorOnPrimary),
    )
}

internal fun resolveTypeface(
    context: Context,
    typography: PinTheme.Typography,
): android.graphics.Typeface? {
    // 1. Direct Typeface (e.g. loaded from ReactFontManager for RN apps)
    if (typography.typeface != null) return typography.typeface

    // 2. Font family name string
    if (typography.fontFamily != null) {
        return android.graphics.Typeface.create(typography.fontFamily, android.graphics.Typeface.NORMAL)
    }

    // 3. android.R.attr.fontFamily from host Material theme
    val tv = TypedValue()
    val resolved = context.theme.resolveAttribute(android.R.attr.fontFamily, tv, true)
    if (!resolved) return null

    if (tv.resourceId != 0) {
        return try {
            ResourcesCompat.getFont(context, tv.resourceId)
        } catch (_: Exception) {
            null
        }
    }
    // Some themes set fontFamily as a string (e.g. "sans-serif-medium")
    if (tv.type == TypedValue.TYPE_STRING && tv.string != null) {
        return try {
            android.graphics.Typeface.create(tv.string.toString(), android.graphics.Typeface.NORMAL)
        } catch (_: Exception) {
            null
        }
    }
    return null
}

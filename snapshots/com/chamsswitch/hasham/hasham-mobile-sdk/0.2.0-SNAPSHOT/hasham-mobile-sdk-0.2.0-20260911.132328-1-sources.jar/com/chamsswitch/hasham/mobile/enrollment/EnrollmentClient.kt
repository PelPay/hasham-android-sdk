package com.chamsswitch.hasham.mobile.enrollment

import com.chamsswitch.hasham.mobile.HashamMobileConfig
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

internal class EnrollmentClient(
    private val config: HashamMobileConfig,
    private val discovery: DiscoveryClient,
) {

    data class AttestRequest(
        val deviceId:           String,
        val enrollmentToken:    String,
        val platform:           String,
        val attestation:        String,           // base64 Play Integrity token
        val keyAttestationChain: String?,         // comma-separated base64 DER certs
        val publicKeyModulus:   String,           // hex
        val publicKeyExponent:  String,           // hex
        val sdkVersion:         String,           // e.g. "1.0.0"
        val sdkChecksum:        String,           // SHA-256 hex of SDK binary
        val sdkPublicKeyPem:    String,           // EC P-256 SPKI PEM — TEE-generated
        val sdkSignature:       String,           // compact JWS over device_id:version:checksum
    )

    data class AttestResponse(
        val deviceId:          String,
        val wrappedWorkingKey: String,            // hex — RSA-OAEP encrypted working key
        val encPublicKey:      String?,           // RSA PEM for PAN wrapping; null if not configured
    )

    fun attest(request: AttestRequest): AttestResponse {
        val body = JSONObject().apply {
            put("device_id",        request.deviceId)
            put("enrollment_token", request.enrollmentToken)
            put("platform",         request.platform)
            put("attestation",      request.attestation)
            if (request.keyAttestationChain != null) {
                put("key_attestation", request.keyAttestationChain)
            }
            put("public_key", JSONObject().apply {
                put("modulus",  request.publicKeyModulus)
                put("exponent", request.publicKeyExponent)
            })
            put("sdk_version",    request.sdkVersion)
            put("sdk_checksum",   request.sdkChecksum)
            put("sdk_public_key", request.sdkPublicKeyPem)
            put("sdk_signature",  request.sdkSignature)
        }.toString()

        val url = URL(discovery.discover().attestationEndpoint)
        val connection = url.openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "POST"
            connection.setRequestProperty("Content-Type", "application/json")
            connection.setRequestProperty("Accept", "application/json")
            connection.doOutput = true
            connection.connectTimeout = config.timeoutMs.toInt()
            connection.readTimeout    = config.timeoutMs.toInt()
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

            val status = connection.responseCode
            val responseBody = (if (status in 200..299) connection.inputStream else connection.errorStream)
                .let { BufferedReader(InputStreamReader(it)) }
                .use { it.readText() }

            if (status !in 200..299) {
                val code = runCatching {
                    JSONObject(responseBody).optString("error", "UNKNOWN")
                }.getOrDefault("UNKNOWN")
                throw EnrollmentException("Attestation failed (HTTP $status): $code")
            }

            val json = JSONObject(responseBody)
            return AttestResponse(
                deviceId          = json.getString("device_id"),
                wrappedWorkingKey = json.getString("wrapped_working_key"),
                encPublicKey      = json.optString("enc_public_key").takeIf { it.isNotEmpty() },
            )
        } finally {
            connection.disconnect()
        }
    }
}

class EnrollmentException(message: String, cause: Throwable? = null) : Exception(message, cause)

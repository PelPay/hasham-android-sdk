package com.chamsswitch.hasham.mobile.enrollment

import com.chamsswitch.hasham.mobile.HashamMobileConfig
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

internal class DiscoveryClient(private val config: HashamMobileConfig) {

    data class Doc(val attestationEndpoint: String)

    @Volatile private var cached: Doc? = null

    fun discover(): Doc {
        cached?.let { return it }
        val url = URL(config.discoveryUrl)
        val connection = url.openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "GET"
            connection.setRequestProperty("Accept", "application/json")
            connection.connectTimeout = config.timeoutMs.toInt()
            connection.readTimeout    = config.timeoutMs.toInt()

            val status = connection.responseCode
            val body = BufferedReader(InputStreamReader(connection.inputStream))
                .use { it.readText() }
            if (status !in 200..299) {
                throw EnrollmentException("Discovery failed (HTTP $status)")
            }

            val json = JSONObject(body)
            val doc = Doc(attestationEndpoint = json.getString("attestation_endpoint"))
            cached = doc
            return doc
        } finally {
            connection.disconnect()
        }
    }
}

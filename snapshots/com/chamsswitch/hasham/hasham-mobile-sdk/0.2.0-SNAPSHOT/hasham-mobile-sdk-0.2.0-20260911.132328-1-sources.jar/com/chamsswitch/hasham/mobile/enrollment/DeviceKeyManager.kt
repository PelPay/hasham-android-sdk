package com.chamsswitch.hasham.mobile.enrollment

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.chamsswitch.hasham.mobile.buildCompactJws
import com.chamsswitch.hasham.mobile.derToRawEcdsa
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.Signature
import java.security.interfaces.RSAPublicKey
import java.security.spec.ECGenParameterSpec
import java.security.spec.PKCS8EncodedKeySpec
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.spec.OAEPParameterSpec
import javax.crypto.spec.PSource
import java.security.spec.MGF1ParameterSpec

/**
 * Manages two key pairs:
 *
 * 1. Per-device RSA-2048 (JCE/BouncyCastle) — used to unwrap the SSM working key.
 *    Generated outside Android Keystore to avoid Keymaster RSA decryption bugs on
 *    emulators and uncertified devices. Private key is stored as PKCS8 DER in
 *    EncryptedSharedPreferences (AES-256-GCM, backed by a hardware Keystore master key).
 *    Re-created on re-enrollment.
 *
 * 2. SDK identity EC P-256 (Android Keystore) — proves this is a genuine Hasham SDK binary.
 *    Stable across re-enrollments; only regenerated when absent.
 *    Signs (device_id:sdk_version:sdk_checksum) as a compact JWS for IAM validation.
 */
internal class DeviceKeyManager(context: Context) {

    private val keyStore = KeyStore.getInstance("AndroidKeyStore").also { it.load(null) }

    private val prefs by lazy {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            "hasham_device_id",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    }

    // MARK: - Device ID

    fun getOrCreateDeviceId(): String {
        val stored = prefs.getString(PREF_DEVICE_ID, null)
        if (stored != null) return stored
        val new = UUID.randomUUID().toString()
        prefs.edit().putString(PREF_DEVICE_ID, new).apply()
        return new
    }

    // MARK: - RSA device key pair (JCE — for SSM working key unwrap)

    fun ensureKeyPair(deviceId: String, @Suppress("UNUSED_PARAMETER") challenge: ByteArray): RSAPublicKey {
        // Generate with standard JCE (BouncyCastle), not AndroidKeyStore.
        // Android Keystore's software Keymaster returns KM_ERROR_UNKNOWN_ERROR for all
        // RSA decrypt operations on emulators and some uncertified devices.
        // The private key is protected at rest by EncryptedSharedPreferences (AES-256-GCM).
        val keyPair = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.generateKeyPair()
        val privateKeyB64 = Base64.encodeToString(keyPair.private.encoded, Base64.NO_WRAP)
        prefs.edit().putString(rsaPrivatePrefKey(deviceId), privateKeyB64).apply()
        val pub = keyPair.public as RSAPublicKey
        android.util.Log.d("HashamDebug", "ensureKeyPair: generated JCE RSA-2048 modLen=${pub.modulus.bitLength()} pkB64len=${privateKeyB64.length}")
        return pub
    }

    fun publicKeyComponents(publicKey: RSAPublicKey): Pair<String, String> {
        fun stripLeadingZero(bytes: ByteArray): ByteArray =
            if (bytes.isNotEmpty() && bytes[0] == 0.toByte()) bytes.copyOfRange(1, bytes.size) else bytes
        val modulus  = stripLeadingZero(publicKey.modulus.toByteArray())
        val exponent = stripLeadingZero(publicKey.publicExponent.toByteArray())
        return modulus.toHex() to exponent.toHex()
    }

    // JCE-generated keys have no Keystore attestation chain.
    // IAM ignores this field when SKIP_PLATFORM_ATTESTATION=true.
    fun keyAttestationChain(@Suppress("UNUSED_PARAMETER") deviceId: String): String = ""

    fun unwrapWorkingKey(deviceId: String, wrappedKeyHex: String): ByteArray {
        val privateKeyB64 = prefs.getString(rsaPrivatePrefKey(deviceId), null)
            ?: throw IllegalStateException("No RSA private key for $deviceId — call ensureKeyPair first")

        // Load with BC to keep key and cipher in the same provider — avoids Conscrypt/BC cross-provider mismatch
        val privateKey = try {
            KeyFactory.getInstance("RSA", "BC")
        } catch (_: Exception) {
            KeyFactory.getInstance("RSA")
        }.generatePrivate(PKCS8EncodedKeySpec(Base64.decode(privateKeyB64, Base64.NO_WRAP)))

        val inputBytes = wrappedKeyHex.hexToBytes()
        android.util.Log.d("HashamDebug", "unwrapWorkingKey: hexLen=${wrappedKeyHex.length} inputBytes=${inputBytes.size} keyProvider=${privateKey.javaClass.name} wrappedPrefix=${wrappedKeyHex.take(16)}")

        // Try each (algorithm, OAEPParams, provider) combination in priority order.
        // .NET RSACng.Decrypt(OaepSHA256) = SHA-256 hash + SHA-256 MGF1 → try BC first (full OAEP implementation),
        // then fall back to default provider, then try SHA-1 MGF1 variants and PKCS1 as last resort.
        data class Variant(val algorithm: String, val params: OAEPParameterSpec?, val provider: String?)
        val variants = listOf(
            // Primary: SHA-256/SHA-256 (= .NET OaepSHA256 = what SSM uses) — BC provider
            Variant("RSA/ECB/OAEPWithSHA-256AndMGF1Padding", OAEPParameterSpec("SHA-256", "MGF1", MGF1ParameterSpec.SHA256, PSource.PSpecified.DEFAULT), "BC"),
            // Same params, default provider (Conscrypt on API 28+)
            Variant("RSA/ECB/OAEPWithSHA-256AndMGF1Padding", OAEPParameterSpec("SHA-256", "MGF1", MGF1ParameterSpec.SHA256, PSource.PSpecified.DEFAULT), null),
            // SHA-256 hash + SHA-1 MGF1 (some HSMs use this interpretation)
            Variant("RSA/ECB/OAEPWithSHA-256AndMGF1Padding", OAEPParameterSpec("SHA-256", "MGF1", MGF1ParameterSpec.SHA1,   PSource.PSpecified.DEFAULT), "BC"),
            Variant("RSA/ECB/OAEPWithSHA-256AndMGF1Padding", OAEPParameterSpec("SHA-256", "MGF1", MGF1ParameterSpec.SHA1,   PSource.PSpecified.DEFAULT), null),
            // SHA-1 / SHA-1 legacy
            Variant("RSA/ECB/OAEPPadding",                   OAEPParameterSpec("SHA-1",   "MGF1", MGF1ParameterSpec.SHA1,   PSource.PSpecified.DEFAULT), "BC"),
            Variant("RSA/ECB/OAEPPadding",                   OAEPParameterSpec("SHA-1",   "MGF1", MGF1ParameterSpec.SHA1,   PSource.PSpecified.DEFAULT), null),
            // PKCS1 fallbacks
            Variant("RSA/ECB/PKCS1Padding", null, "BC"),
            Variant("RSA/ECB/PKCS1Padding", null, null),
        )

        for ((algorithm, params, provider) in variants) {
            try {
                val cipher = if (provider != null) Cipher.getInstance(algorithm, provider) else Cipher.getInstance(algorithm)
                if (params != null) cipher.init(Cipher.DECRYPT_MODE, privateKey, params)
                else cipher.init(Cipher.DECRYPT_MODE, privateKey)
                val workingKey = cipher.doFinal(inputBytes)
                android.util.Log.d("HashamDebug", "unwrapWorkingKey: $algorithm (provider=$provider) succeeded, workingKeyLen=${workingKey.size}, hex=${workingKey.toHex()}")
                return workingKey
            } catch (e: Exception) {
                android.util.Log.w("HashamDebug", "unwrapWorkingKey FAILED $algorithm (provider=$provider): ${e::class.java.simpleName}: ${e.message}")
            }
        }
        throw IllegalStateException("RSA decryption failed with all padding variants — check SSM OAEP/PKCS1 configuration")
    }

    // MARK: - SDK identity EC P-256 key pair (Android Keystore)

    /** Ensure the SDK identity key pair exists in Keystore, creating it if absent. */
    fun ensureSdkKeyPair() {
        if (keyStore.containsAlias(SDK_KEY_ALIAS)) return
        val spec = KeyGenParameterSpec.Builder(SDK_KEY_ALIAS, KeyProperties.PURPOSE_SIGN)
            .setAlgorithmParameterSpec(ECGenParameterSpec("secp256r1"))
            .setDigests(KeyProperties.DIGEST_SHA256)
            .build()
        KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_EC, "AndroidKeyStore")
            .also { it.initialize(spec) }
            .generateKeyPair()
    }

    /**
     * Returns the SDK identity public key as a PEM-encoded SPKI string.
     * IAM stores this during enrollment and uses it to verify future sdk_signatures.
     */
    fun sdkPublicKeyPem(): String {
        ensureSdkKeyPair()
        val publicKey = keyStore.getCertificate(SDK_KEY_ALIAS).publicKey
        // publicKey.encoded is already SPKI DER for Android Keystore EC keys
        val b64 = Base64.encodeToString(publicKey.encoded, Base64.NO_WRAP)
        val body = b64.chunked(64).joinToString("\n")
        return "-----BEGIN PUBLIC KEY-----\n$body\n-----END PUBLIC KEY-----"
    }

    /**
     * Signs `device_id:sdk_version:sdk_checksum` with the SDK EC private key and returns
     * a compact JWS (ES256). IAM calls jose's compactVerify to validate it.
     */
    fun signSdkEnrollment(deviceId: String, sdkVersion: String, sdkChecksum: String): String {
        ensureSdkKeyPair()
        val privateKey = keyStore.getKey(SDK_KEY_ALIAS, null) as PrivateKey
        val payload = "$deviceId:$sdkVersion:$sdkChecksum".toByteArray(Charsets.UTF_8)

        return buildCompactJws(payload) { signingInput ->
            val sig = Signature.getInstance("SHA256withECDSA").apply {
                initSign(privateKey)
                update(signingInput)
            }
            derToRawEcdsa(sig.sign())    // JWS ES256 requires raw R||S, not ASN.1 DER
        }
    }

    /**
     * Signs `device:{deviceId}:op:{signedAt}` with the SDK EC P-256 Keystore key as a
     * compact JWS (ES256). IAM's POST /mobile/devices/:deviceId/token verifies this to
     * prove the genuine Hasham SDK binary was present at the time of the operation.
     */
    fun signSdkOperation(deviceId: String, signedAt: Long): String {
        ensureSdkKeyPair()
        val privateKey = keyStore.getKey(SDK_KEY_ALIAS, null) as PrivateKey
        val payload = "device:$deviceId:op:$signedAt".toByteArray(Charsets.UTF_8)
        return buildCompactJws(payload) { signingInput ->
            val sig = Signature.getInstance("SHA256withECDSA").apply {
                initSign(privateKey)
                update(signingInput)
            }
            derToRawEcdsa(sig.sign())
        }
    }

    /**
     * Signs `device:{deviceId}:op:{signedAt}` with the stored JCE RSA-2048 private key
     * using SHA256withRSA. Returns the signature as a standard Base64 string.
     * IAM's POST /mobile/devices/:deviceId/token verifies this to prove device presence.
     */
    fun signOperation(deviceId: String, signedAt: Long): String {
        val privateKeyB64 = prefs.getString(rsaPrivatePrefKey(deviceId), null)
            ?: throw IllegalStateException("No RSA private key for $deviceId — call ensureKeyPair first")
        val privateKey = KeyFactory.getInstance("RSA")
            .generatePrivate(PKCS8EncodedKeySpec(Base64.decode(privateKeyB64, Base64.NO_WRAP)))
        val payload = "device:$deviceId:op:$signedAt".toByteArray(Charsets.UTF_8)
        val sigBytes = Signature.getInstance("SHA256withRSA").apply {
            initSign(privateKey)
            update(payload)
        }.sign()
        return Base64.encodeToString(sigBytes, Base64.NO_WRAP)
    }

    // MARK: - Private

    private fun rsaPrivatePrefKey(deviceId: String) = "$PREF_RSA_PRIVATE_KEY$deviceId"

    companion object {
        private const val PREF_DEVICE_ID      = "device_id"
        private const val PREF_RSA_PRIVATE_KEY = "rsa_pk_"
        private const val SDK_KEY_ALIAS        = "com.chamsswitch.hasham.sdk.ec"
    }
}

internal fun ByteArray.toHex() = joinToString("") { "%02x".format(it) }
internal fun String.hexToBytes() = chunked(2).map { it.toInt(16).toByte() }.toByteArray()

package com.chamsswitch.hasham.mobile.ui

/**
 * Optional visual overrides for the SDK-rendered PIN and PAN entry overlays.
 * Any Color field left null is resolved from the host app's active Material theme attributes
 * (?attr/colorPrimary, ?attr/colorSurface, etc.), so the overlays look native for any app
 * without integrator configuration.
 */
data class PinTheme(
    val colors:     Colors     = Colors(),
    val typography: Typography = Typography(),
    val shape:      Shape      = Shape(),
    val strings:    Strings    = Strings(),
    val pinLength:  Int        = 4,
) {
    /**
     * Color overrides. Leave any field null to inherit from the host Material theme.
     *
     * Material attribute fallbacks:
     *  - primary/dotFilled  → ?attr/colorPrimary
     *  - background         → ?attr/colorSurface
     *  - keyBackground      → ?attr/colorSurfaceVariant
     *  - keyText/titleColor → ?attr/colorOnSurface
     *  - dotEmpty           → ?attr/colorOutlineVariant
     *  - subtitleColor      → ?attr/colorOnSurfaceVariant
     */
    data class Colors(
        val primary:       Int? = null,
        val background:    Int? = null,
        val keyBackground: Int? = null,
        val keyText:       Int? = null,
        val dotFilled:     Int? = null,
        val dotEmpty:      Int? = null,
        val titleColor:    Int? = null,
        val subtitleColor: Int? = null,
    )

    /**
     * Typography overrides. Resolution priority (highest first):
     *  1. [typeface]   — direct Typeface supplied by the integrator (e.g. from RN FontManager)
     *  2. [fontFamily] — font family name string, passed to Typeface.create
     *  3. android.R.attr.fontFamily from the host Material theme
     *  4. System default
     */
    data class Typography(
        val titleSizeSp:    Float                      = 20f,
        val subtitleSizeSp: Float                      = 14f,
        val keySizeSp:      Float                      = 24f,
        val fontFamily:     String?                    = null,
        val typeface:       android.graphics.Typeface? = null,
    )

    data class Shape(
        val keyShape:     KeyShape = KeyShape.CIRCLE,
        val cornerRadius: Float    = 8f,
    )

    enum class KeyShape { CIRCLE, ROUNDED, SQUARE }

    data class Strings(
        val title:    String = "Enter your PIN",
        val subtitle: String = "Keep your PIN private",
    )
}

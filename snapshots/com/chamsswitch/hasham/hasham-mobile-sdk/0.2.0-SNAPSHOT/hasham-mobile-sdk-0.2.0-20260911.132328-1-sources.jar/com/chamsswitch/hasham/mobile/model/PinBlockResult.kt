package com.chamsswitch.hasham.mobile.model

import android.util.Base64

/**
 * An encrypted ISO-0 PIN block produced by [HashamMobile.createPinBlock].
 *
 * Forward [encryptedBlock] (or its [toBase64] / [toHex] representation) to your backend,
 * which passes it to the Card API. The raw PIN never leaves the SDK.
 */
class PinBlockResult(
    /** Encrypted PIN block bytes — 8 bytes for 3DES, 16 bytes for AES. */
    val encryptedBlock: ByteArray,
) {
    fun toBase64(): String = Base64.encodeToString(encryptedBlock, Base64.NO_WRAP)
    fun toHex(): String = encryptedBlock.joinToString("") { "%02x".format(it) }

    override fun equals(other: Any?): Boolean =
        other is PinBlockResult && encryptedBlock.contentEquals(other.encryptedBlock)

    override fun hashCode(): Int = encryptedBlock.contentHashCode()
}

package com.chamsswitch.hasham.mobile.model

/**
 * Result of [com.chamsswitch.hasham.mobile.HashamMobile.sign].
 * Forward all three values to your backend for the IAM device-token exchange.
 */
data class SignResult(
    /**
     * Base64 SHA256withRSA signature of `device:{deviceId}:op:{signedAt}`, produced
     * by the device JCE RSA-2048 private key. Passed to IAM as `device_signature`.
     */
    val deviceSignature: String,
    /**
     * Compact JWS (ES256) signed by the SDK EC P-256 Keystore key with payload
     * `device:{deviceId}:op:{signedAt}`. Passed to IAM as `sdk_signature`.
     * IAM verifies this proves the genuine Hasham SDK binary was present.
     */
    val sdkSignature: String,
    /** Unix timestamp (seconds) used in both signatures. */
    val signedAt: Long,
)

package com.chamsswitch.hasham.mobile.pin

import com.chamsswitch.hasham.mobile.model.PinBlockResult
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec

/**
 * Builds and encrypts ISO-0 PIN blocks.
 *
 * The [pin] array is zeroed immediately after the PIN block is formatted —
 * the plaintext PIN digits exist in memory only for the duration of [build].
 */
internal class PinBlockBuilder {

    fun build(pin: CharArray, pan: String, workingKeyBytes: ByteArray): PinBlockResult {
        require(pin.size in 4..12) { "PIN must be 4–12 digits" }
        require(pan.length in 12..19 && pan.all { it.isDigit() }) { "PAN must be 12–19 digits" }

        val pinBlock: ByteArray
        try {
            pinBlock = formatIso0(pin, pan)
        } finally {
            pin.fill('0')
        }

        val encrypted = encrypt(pinBlock, workingKeyBytes)
        pinBlock.fill(0)

        return PinBlockResult(encrypted)
    }

    /**
     * ISO-0 (ISO 9564-1 Format 0) PIN block.
     *
     * PIN block:  0 | len(PIN) | PIN digits | 'F' padding → 8 bytes
     * PAN block:  0000 | rightmost 12 PAN digits excluding check digit → 8 bytes
     * Result:     XOR(PIN block, PAN block)
     */
    private fun formatIso0(pin: CharArray, pan: String): ByteArray {
        val pinHex = buildString(16) {
            append('0')
            append(pin.size.toString(16).uppercase())
            pin.forEach { append(it) }
            repeat(16 - 2 - pin.size) { append('F') }
        }

        val panCore = pan.dropLast(1).filter { it.isDigit() }.takeLast(12).padStart(12, '0')
        val panHex = "0000$panCore"

        val pinBytes = hexToBytes(pinHex)
        val panBytes = hexToBytes(panHex)
        return ByteArray(8) { i -> (pinBytes[i].toInt() xor panBytes[i].toInt()).toByte() }
    }

    private fun encrypt(pinBlock: ByteArray, workingKey: ByteArray): ByteArray {
        return when (workingKey.size) {
            16, 24 -> tripleDesEcb(pinBlock, workingKey)
            32     -> aesEcb(pinBlock.copyOf(16), workingKey)  // zero-pad ISO-0 block to 16 bytes for AES
            else   -> throw IllegalArgumentException("Unsupported working key length: ${workingKey.size}")
        }
    }

    private fun tripleDesEcb(data: ByteArray, key: ByteArray): ByteArray {
        // 3DES-ECB, no padding — ISO-0 block is exactly 8 bytes
        // If 16-byte key: extend to 24 bytes by appending the first 8 bytes (2-key 3DES → 3-key)
        val keyBytes = if (key.size == 16) key + key.copyOfRange(0, 8) else key
        val secretKey = SecretKeySpec(keyBytes, "DESede")
        return Cipher.getInstance("DESede/ECB/NoPadding")
            .also { it.init(Cipher.ENCRYPT_MODE, secretKey) }
            .doFinal(data)
    }

    private fun aesEcb(data: ByteArray, key: ByteArray): ByteArray {
        val secretKey = SecretKeySpec(key, "AES")
        return Cipher.getInstance("AES/ECB/NoPadding")
            .also { it.init(Cipher.ENCRYPT_MODE, secretKey) }
            .doFinal(data)
    }

    private fun hexToBytes(hex: String): ByteArray =
        ByteArray(hex.length / 2) { i -> hex.substring(i * 2, i * 2 + 2).toInt(16).toByte() }
}

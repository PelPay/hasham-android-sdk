package com.chamsswitch.hasham.mobile.model

/**
 * Result of [com.chamsswitch.hasham.mobile.HashamMobile.changePIN].
 * Forward all three values to your backend PIN-change endpoint.
 */
data class ChangePinResult(
    /** Hex ISO-0 PIN block for the current PIN, encrypted with the device working key. */
    val oldPinBlock: String,
    /** Hex ISO-0 PIN block for the new PIN, encrypted with the device working key. */
    val newPinBlock: String,
    /**
     * Base64 RSA-OAEP-SHA256 encrypted PAN.
     * Encrypted using the enc_public_key returned by IAM during attestation.
     * The Card API decrypts this with the matching private key stored in Vault.
     */
    val wrappedPan: String,
)

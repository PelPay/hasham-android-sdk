package com.chamsswitch.hasham.mobile

import android.content.Context
import android.util.Base64
import java.security.MessageDigest
import java.util.zip.ZipFile

// SDK_CHECKSUM is replaced by the release build script with the SHA-256 of the compiled AAR's
// classes.dex. Do not edit manually — CI sets this before the final compilation step.
internal const val SDK_VERSION  = "1.0.0"
internal const val SDK_CHECKSUM = "0000000000000000000000000000000000000000000000000000000000000000"

/**
 * Computes the SHA-256 of the SDK's own classes.dex inside the host APK.
 *
 * This is the same value registered in IAM when the SDK version is published.
 * The release build script regenerates SDK_CHECKSUM from the AAR before shipping,
 * so this runtime value matches the compile-time constant on genuine builds.
 * A tampered SDK will produce a different hash and fail IAM's registry check.
 */
internal fun computeSdkChecksum(context: Context): String {
    val digest = MessageDigest.getInstance("SHA-256")
    ZipFile(context.packageCodePath).use { apk ->
        val entry = apk.getEntry("classes.dex")
            ?: return SDK_CHECKSUM  // fallback to build-time constant in test environments
        apk.getInputStream(entry).use { stream ->
            val buf = ByteArray(8192)
            var read: Int
            while (stream.read(buf).also { read = it } != -1) digest.update(buf, 0, read)
        }
    }
    return digest.digest().joinToString("") { "%02x".format(it) }
}

/**
 * Builds a compact JWS (RFC 7515) signed with ES256.
 * IAM verifies this with jose's compactVerify, which expects the three-part dot-separated form.
 */
internal fun buildCompactJws(payloadBytes: ByteArray, sign: (ByteArray) -> ByteArray): String {
    val headerB64  = base64url("""{"alg":"ES256"}""".toByteArray(Charsets.UTF_8))
    val payloadB64 = base64url(payloadBytes)
    val signingInput = "$headerB64.$payloadB64".toByteArray(Charsets.US_ASCII)
    val rawSig = sign(signingInput)          // caller supplies the DER→raw conversion
    return "$headerB64.$payloadB64.${base64url(rawSig)}"
}

internal fun base64url(bytes: ByteArray): String =
    Base64.encodeToString(bytes, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)

/** Convert DER-encoded ECDSA signature (from Android Keystore) to raw R||S (64 bytes) for JWS. */
internal fun derToRawEcdsa(der: ByteArray): ByteArray {
    var i = 2                                           // skip 0x30 + total length
    val rLen = der[i + 1].toInt() and 0xFF; i += 2
    val r = der.copyOfRange(i, i + rLen); i += rLen
    val sLen = der[i + 1].toInt() and 0xFF; i += 2
    val s = der.copyOfRange(i, i + sLen)

    fun pad32(b: ByteArray): ByteArray {
        val stripped = if (b.size > 32) b.copyOfRange(b.size - 32, b.size) else b
        return ByteArray(32 - stripped.size) + stripped
    }
    return pad32(r) + pad32(s)
}

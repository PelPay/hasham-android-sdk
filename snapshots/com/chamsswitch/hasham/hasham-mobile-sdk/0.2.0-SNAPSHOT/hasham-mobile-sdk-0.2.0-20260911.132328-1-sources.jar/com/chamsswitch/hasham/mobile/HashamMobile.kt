package com.chamsswitch.hasham.mobile

import android.content.Context
import android.util.Base64
import androidx.fragment.app.FragmentActivity
import com.chamsswitch.hasham.mobile.enrollment.DeviceKeyManager
import com.chamsswitch.hasham.mobile.enrollment.DiscoveryClient
import com.chamsswitch.hasham.mobile.enrollment.EncPublicKeyManager
import com.chamsswitch.hasham.mobile.enrollment.EnrollmentClient
import com.chamsswitch.hasham.mobile.model.ChangePinResult
import com.chamsswitch.hasham.mobile.model.EnrollmentResult
import com.chamsswitch.hasham.mobile.model.PinBlockResult
import com.chamsswitch.hasham.mobile.model.SignResult
import com.chamsswitch.hasham.mobile.pin.PinBlockBuilder
import com.chamsswitch.hasham.mobile.pin.WorkingKeyManager
import com.chamsswitch.hasham.mobile.ui.PanEntryFragment
import com.chamsswitch.hasham.mobile.ui.PinEntryFragment
import com.chamsswitch.hasham.mobile.ui.PinTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import com.chamsswitch.hasham.mobile.computeSdkChecksum

/**
 * Hasham Mobile SDK — device enrollment and PIN block operations.
 *
 * ## Setup
 * ```kotlin
 * // Production — uses default discovery URL (api.chamsswitch.com)
 * val hasham = HashamMobile.Builder(context).build()
 *
 * // Staging / dev — override the well-known endpoint
 * val hasham = HashamMobile.Builder(context)
 *     .discoveryUrl("https://api.dev.chamsswitch.com/auth/.well-known/mobile-sdk")
 *     .build()
 * ```
 *
 * ## Enrollment (one-time per key pair)
 * ```kotlin
 * // 1. Fetch enrollment token from your backend
 * val token = myBackend.getEnrollmentToken()
 *
 * // 2. Get challenge from token to use as Play Integrity nonce
 * val nonce = hasham.extractChallenge(token)
 *
 * // 3. Request Play Integrity token (nonce must match challenge)
 * val integrityToken = playIntegrity.requestIntegrityToken(nonce)
 *
 * // 4. Enroll — stores working key, returns deviceId
 * val result = hasham.enroll(token, integrityToken)
 * myStorage.saveDeviceId(result.deviceId)
 * ```
 *
 * ## PIN block (each PIN operation)
 * ```kotlin
 * val pinBlock = hasham.createPinBlock(pan = "4111111111111111", pin = pinDigits)
 * myBackend.changePIN(deviceId, pinBlock.toBase64())
 * ```
 *
 * ## Security model
 * - The device RSA-2048 private key lives in hardware (TEE/StrongBox), never exported.
 * - The working key is protected by a hardware-backed AES-256-GCM envelope key in Android Keystore.
 *   Even code running in the same process cannot obtain the raw working key bytes.
 * - The plaintext PIN digits and the decrypted working key exist in memory only for the
 *   duration of [createPinBlock] and are zeroed before the call returns.
 */
class HashamMobile private constructor(
    private val context: Context,
    private val config: HashamMobileConfig,
    private val keyManager: DeviceKeyManager,
    private val workingKeyManager: WorkingKeyManager,
    private val encPublicKeyManager: EncPublicKeyManager,
    private val enrollmentClient: EnrollmentClient,
    private val pinBlockBuilder: PinBlockBuilder,
) {

    /** Returns the stable device ID for this installation. */
    fun getDeviceId(): String = keyManager.getOrCreateDeviceId()

    /** Returns true if this device has a stored working key (i.e. enrollment completed). */
    fun isEnrolled(): Boolean = workingKeyManager.isEnrolled(getDeviceId())

    /**
     * Extract the `challenge` claim from an enrollment token for use as the Play Integrity nonce.
     * Call this before requesting the Play Integrity token — the nonce must match the challenge.
     */
    fun extractChallenge(enrollmentToken: String): String = parseJwtClaim(enrollmentToken, "challenge")

    /**
     * Enroll this device with the IAM platform.
     *
     * Must be called from a coroutine or background thread (performs network I/O).
     * Safe to call again to re-enroll with a fresh key pair and new enrollment token.
     *
     * @param enrollmentToken JWT from your tenant backend (signed with tenant EC key)
     * @param playIntegrityToken Base64-encoded Play Integrity token (nonce = challenge)
     * @param keyAttestationChain Optional comma-separated Base64 DER cert chain from
     *        Android Key Attestation. The IAM server uses this to verify the RSA key is hardware-backed.
     *        If not supplied, the SDK builds it from the Keystore certificate chain.
     */
    suspend fun enroll(
        enrollmentToken: String,
        playIntegrityToken: String,
        keyAttestationChain: String? = null,
    ): EnrollmentResult = withContext(Dispatchers.IO) {
        val deviceId = keyManager.getOrCreateDeviceId()
        val challenge = extractChallenge(enrollmentToken)

        val publicKey = keyManager.ensureKeyPair(deviceId, challenge.toByteArray(Charsets.UTF_8))
        val (modulus, exponent) = keyManager.publicKeyComponents(publicKey)
        val certChain = keyAttestationChain ?: keyManager.keyAttestationChain(deviceId).ifBlank { null }

        val sdkChecksum  = computeSdkChecksum(context)
        val sdkPublicKey = keyManager.sdkPublicKeyPem()
        val sdkSignature = keyManager.signSdkEnrollment(deviceId, SDK_VERSION, sdkChecksum)

        val response = enrollmentClient.attest(
            EnrollmentClient.AttestRequest(
                deviceId            = deviceId,
                enrollmentToken     = enrollmentToken,
                platform            = "android",
                attestation         = playIntegrityToken,
                keyAttestationChain = certChain,
                publicKeyModulus    = modulus,
                publicKeyExponent   = exponent,
                sdkVersion          = SDK_VERSION,
                sdkChecksum         = sdkChecksum,
                sdkPublicKeyPem     = sdkPublicKey,
                sdkSignature        = sdkSignature,
            )
        )

        val workingKeyBytes = keyManager.unwrapWorkingKey(deviceId, response.wrappedWorkingKey)
        workingKeyManager.store(deviceId, workingKeyBytes)  // store() zeros workingKeyBytes

        if (response.encPublicKey != null) {
            encPublicKeyManager.store(deviceId, response.encPublicKey)
        }

        EnrollmentResult(deviceId = response.deviceId)
    }

    /**
     * Present a themed PIN entry bottom sheet and return an encrypted ISO-0 PIN block.
     *
     * The raw PIN digits are handled entirely inside the SDK — they never pass through the
     * host app's code. The bottom sheet is dismissed automatically on confirm or cancel.
     *
     * @param activity The [FragmentActivity] used to show the bottom sheet.
     * @param pan Full card PAN (digits only, 12–19 chars). Fetch from your backend
     *   immediately before calling; do not store it in the app.
     * @param theme Optional visual configuration. Defaults to Chamsswitch brand colours.
     * @throws IllegalStateException with message "CANCELLED" if the user dismisses the sheet.
     */
    suspend fun capturePIN(
        activity: FragmentActivity,
        pan: String,
        theme: PinTheme = PinTheme(),
    ): PinBlockResult = withContext(Dispatchers.Main) {
        val fragment = PinEntryFragment.newInstance(theme)
        fragment.show(activity.supportFragmentManager, "pin_entry")

        val digits: CharArray = try {
            fragment.awaitPin()
        } catch (e: Exception) {
            fragment.dismissAllowingStateLoss()
            throw e
        }

        fragment.dismissAllowingStateLoss()

        withContext(Dispatchers.Default) {
            workingKeyManager.withKey(getDeviceId()) { workingKeyBytes ->
                pinBlockBuilder.build(digits, pan, workingKeyBytes)
            }
        }
    }

    /**
     * Create an ISO-0 encrypted PIN block directly.
     *
     * Prefer [capturePIN] — that method renders a secure PIN entry overlay so the host app
     * never handles raw digits. Use this only if you manage PIN collection through a custom
     * accessibility flow.
     *
     * @param pan Full card PAN (digits only, including check digit, 12–19 chars)
     * @param pin PIN digits as a CharArray — **zeroed after this call, do not reuse**
     */
    fun createPinBlock(pan: String, pin: CharArray): PinBlockResult =
        workingKeyManager.withKey(getDeviceId()) { workingKeyBytes ->
            pinBlockBuilder.build(pin, pan, workingKeyBytes)
        }

    /**
     * Multi-step PIN change overlay — optional PAN collection, then old PIN → new PIN → confirm.
     *
     * **Virtual cards** (`pan` provided): goes straight to PIN entry.
     *
     * **Physical cards** (`maskedPan` provided): shows a PAN entry screen first so the
     * cardholder can type the hidden digits from their physical card. The SDK reconstructs
     * the full PAN internally before proceeding to PIN entry.
     *
     * After all steps the SDK builds ISO-0 blocks for both PINs and wraps the PAN with
     * RSA-OAEP-SHA256 using the enc_public_key stored at enrollment.
     *
     * @param activity  The [FragmentActivity] used to show the bottom sheets.
     * @param pan       Full card PAN (digits only, 12–19 chars). Use for virtual cards.
     * @param maskedPan Masked PAN where '*' marks hidden digits, e.g. "4111 **** **** 1234".
     *                  Use for physical cards — the SDK shows a digit-entry step first.
     * @param theme     Optional visual configuration.
     * @throws IllegalStateException with message "CANCELLED" if the user dismisses a sheet.
     */
    suspend fun changePIN(
        activity:  FragmentActivity,
        pan:       String? = null,
        maskedPan: String? = null,
        theme:     PinTheme = PinTheme(),
    ): ChangePinResult {
        require(pan != null || maskedPan != null) {
            "Either pan or maskedPan must be provided"
        }

        val resolvedPan: String = if (pan != null) {
            pan
        } else {
            capturePhysicalPan(activity, maskedPan!!, theme)
        }

        val oldDigits = captureStep(
            activity,
            theme.copy(strings = PinTheme.Strings(title = "Enter your current PIN", subtitle = "")),
        )
        try {
            val newDigits = captureNewPin(activity, theme)
            return withContext(Dispatchers.Default) {
                val deviceId = getDeviceId()
                workingKeyManager.withKey(deviceId) { workingKeyBytes ->
                    val oldBlock = pinBlockBuilder.build(oldDigits, resolvedPan, workingKeyBytes)
                    val newBlock = pinBlockBuilder.build(newDigits, resolvedPan, workingKeyBytes)
                    val wrapped  = encPublicKeyManager.wrapPan(deviceId, resolvedPan)
                    ChangePinResult(
                        oldPinBlock = oldBlock.toHex(),
                        newPinBlock = newBlock.toHex(),
                        wrappedPan  = wrapped,
                    )
                }
            }
        } catch (e: Exception) {
            oldDigits.fill('0')
            throw e
        }
    }

    private suspend fun capturePhysicalPan(
        activity:  FragmentActivity,
        maskedPan: String,
        theme:     PinTheme,
    ): String {
        val stripped = maskedPan.replace(" ", "")
        if (!stripped.contains('*')) return stripped

        return withContext(Dispatchers.Main) {
            val fragment = PanEntryFragment.newInstance(maskedPan, theme)
            fragment.show(activity.supportFragmentManager, "pan_entry")
            val pan = try {
                fragment.awaitPan()
            } catch (e: Exception) {
                fragment.dismissAllowingStateLoss()
                throw e
            }
            fragment.dismissAllowingStateLoss()
            pan
        }
    }

    private suspend fun captureNewPin(activity: FragmentActivity, theme: PinTheme): CharArray {
        var mismatch = false
        while (true) {
            val attempt = captureStep(
                activity,
                theme.copy(strings = PinTheme.Strings(
                    title    = "Enter your new PIN",
                    subtitle = if (mismatch) "PINs did not match — try again" else "",
                )),
            )
            val confirm = try {
                captureStep(
                    activity,
                    theme.copy(strings = PinTheme.Strings(title = "Confirm your new PIN", subtitle = "")),
                )
            } catch (e: Exception) {
                attempt.fill('0')
                throw e
            }
            if (attempt.contentEquals(confirm)) {
                confirm.fill('0')
                return attempt
            }
            attempt.fill('0')
            confirm.fill('0')
            mismatch = true
        }
    }

    private suspend fun captureStep(activity: FragmentActivity, theme: PinTheme): CharArray =
        withContext(Dispatchers.Main) {
            val fragment = PinEntryFragment.newInstance(theme)
            fragment.show(activity.supportFragmentManager, "pin_entry")
            val digits = try {
                fragment.awaitPin()
            } catch (e: Exception) {
                fragment.dismissAllowingStateLoss()
                throw e
            }
            fragment.dismissAllowingStateLoss()
            digits
        }

    /** Remove all enrollment data for this device (working key + envelope key). */
    fun clearEnrollment() {
        workingKeyManager.clear(getDeviceId())
    }

    /**
     * Signs `device:{deviceId}:op:{signedAt}` with the device JCE RSA-2048 private key.
     * Returns the Base64 signature and the Unix timestamp used, ready to pass to your
     * backend for the IAM device-token exchange before any card operation.
     *
     * @param signedAt Unix timestamp in seconds. Defaults to the current time.
     */
    fun sign(signedAt: Long = System.currentTimeMillis() / 1000L): SignResult {
        val deviceId = getDeviceId()
        return SignResult(
            deviceSignature = keyManager.signOperation(deviceId, signedAt),
            sdkSignature    = keyManager.signSdkOperation(deviceId, signedAt),
            signedAt        = signedAt,
        )
    }

    private fun parseJwtClaim(jwt: String, claim: String): String {
        val payload = jwt.split(".").getOrNull(1)
            ?: throw IllegalArgumentException("Invalid JWT — missing payload segment")
        val padded = payload.replace('-', '+').replace('_', '/')
            .let { it + "=".repeat((4 - it.length % 4) % 4) }
        val decoded = Base64.decode(padded, Base64.DEFAULT)
        return JSONObject(String(decoded, Charsets.UTF_8)).getString(claim)
    }

    class Builder(private val context: Context) {
        private var discoveryUrl: String = DEFAULT_DISCOVERY_URL
        private var timeoutMs: Long = 30_000L

        fun discoveryUrl(url: String) = apply { discoveryUrl = url }
        fun timeoutMs(ms: Long) = apply { timeoutMs = ms }

        fun build(): HashamMobile {
            val config = HashamMobileConfig(discoveryUrl, timeoutMs)
            val ctx = context.applicationContext
            val discovery = DiscoveryClient(config)
            return HashamMobile(
                context = ctx,
                config = config,
                keyManager = DeviceKeyManager(ctx),
                workingKeyManager = WorkingKeyManager(ctx),
                encPublicKeyManager = EncPublicKeyManager(ctx),
                enrollmentClient = EnrollmentClient(config, discovery),
                pinBlockBuilder = PinBlockBuilder(),
            )
        }

        companion object {
            const val DEFAULT_DISCOVERY_URL =
                "https://api.chamsswitch.com/auth/.well-known/mobile-sdk"
        }
    }
}
